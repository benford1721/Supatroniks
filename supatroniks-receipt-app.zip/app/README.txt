SUPATRONIKS RECEIPT - ANDROID APP (Capacitor)

BUILD THE APK WITHOUT INSTALLING ANYTHING (GitHub Actions)
1. Create a free account at github.com and make a NEW repository.
2. Upload ALL files from this folder to it, including the hidden .github folder
   (easiest from a computer: drag the whole folder into "Add file > Upload files").
3. Open the "Actions" tab > "Build APK" > "Run workflow".
4. After about 5-8 minutes, open the finished run and download "Supatroniks-Receipt-APK".
   Unzip it to get app-debug.apk, copy to your phone, tap it and allow "Install unknown apps".

BUILD WITH ANDROID STUDIO INSTEAD
  npm install && npm run build && npx cap add android && npx cap sync android && npx cap open android
  then Build > Build APK(s).

Saving: Save PNG / Save PDF opens the Android share sheet (Save to Files, WhatsApp, Gmail...).
