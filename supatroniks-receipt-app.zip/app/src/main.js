import "./style.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "@fontsource/inter/800.css";
import "@fontsource/roboto-mono/500.css";
import "@fontsource/roboto-mono/600.css";
import "@fontsource/roboto-mono/700.css";
import React from "react";
import { createRoot } from "react-dom/client";
import html2canvas from "html2canvas-pro";
import { jsPDF } from "jspdf";
import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

const { useState, useMemo, useRef, useEffect, createElement: h } = React;

// Save the file into the app cache and open the Android share sheet
// (Save to Files / WhatsApp / Gmail ...). In a normal browser it downloads.
async function deliver(filename, mime, base64) {
  if (Capacitor.isNativePlatform()) {
    const r = await Filesystem.writeFile({ path: filename, data: base64, directory: Directory.Cache });
    try {
      await Share.share({ title: filename, files: [r.uri], dialogTitle: "Save or share receipt" });
    } catch (e) {
      // Android reports "Share canceled" even after a successful save/share, so ignore it
      if (!/cancel/i.test(String((e && e.message) || e))) throw e;
    }
  } else {
    const a = document.createElement("a");
    a.download = filename; a.href = "data:" + mime + ";base64," + base64;
    document.body.appendChild(a); a.click(); a.remove();
  }
}

const BRANCHES = {
  lagos:{name:"Lagos Office",tag:"Alaba · Ojo",address:"Shop A185B, Alaba International Market, Ojo, Lagos State.",phones:["+234 916 158 0892"]},
  abuja:{name:"Abuja Office",tag:"Kubwa · Abuja",address:"A1 Diwani Plaza, 14 Akufor, Along Aso Savings Road, Off Byazhin Junction, Kubwa, Abuja.",phones:["+234 703 767 8623"]},
  ph:{name:"Port Harcourt Office",tag:"Diobu · PH",address:"74 Nanka, By Iloabuchi, Mile One, Diobu, Port Harcourt, Rivers State.",phones:["+234 706 591 8357","+234 906 5569 855"]}
};
const E = {qty:"",desc:"",rate:""};
const INITIAL_ITEMS = [
  {qty:"1",desc:'65" QLED Smart TV - Hisense 4K UHD, Bluetooth',rate:"485000"},
  {qty:"2",desc:"Power Generator - Sumec Firman 3.5KVA Key Start",rate:"210000"},
  {qty:"1",desc:"Chest Freezer 200L - Nexus Silver",rate:"165000"},
  ...Array.from({length:9},()=>({...E}))
];

// Brand icons (inline SVG so they work offline and in PNG/PDF export)
const P = {
  call:"M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
  mail:"M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",
  whatsapp:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z",
  tiktok:"M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z",
  x:"M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z",
  threads:"M12.186 24h-.007c-3.581-.024-6.334-1.205-8.184-3.509C2.35 18.44 1.5 15.586 1.472 12.01v-.017c.03-3.579.879-6.43 2.525-8.482C5.845 1.205 8.6.024 12.18 0h.014c2.746.02 5.043.725 6.826 2.098 1.677 1.29 2.858 3.13 3.509 5.467l-2.04.569c-1.104-3.96-3.898-5.984-8.304-6.015-2.91.022-5.11.936-6.54 2.717C4.307 6.504 3.616 8.914 3.589 12c.027 3.086.718 5.496 2.057 7.164 1.43 1.783 3.631 2.698 6.54 2.717 2.623-.02 4.358-.631 5.8-2.045 1.647-1.613 1.618-3.593 1.09-4.798-.31-.71-.873-1.3-1.634-1.75-.192 1.352-.622 2.446-1.284 3.272-.886 1.102-2.14 1.704-3.73 1.79-1.202.065-2.361-.218-3.259-.801-1.063-.689-1.685-1.74-1.752-2.964-.065-1.19.408-2.285 1.33-3.082.88-.76 2.119-1.207 3.583-1.291a13.853 13.853 0 0 1 3.02.142c-.126-.742-.375-1.332-.75-1.757-.513-.586-1.308-.883-2.359-.89h-.029c-.844 0-1.992.232-2.721 1.32L7.734 7.847c.98-1.454 2.568-2.256 4.478-2.256h.044c3.194.02 5.097 1.975 5.287 5.388.108.046.216.094.321.142 1.49.7 2.58 1.761 3.154 3.07.797 1.82.871 4.79-1.548 7.158-1.85 1.81-4.094 2.628-7.277 2.65Zm1.003-11.69c-.242 0-.487.007-.739.021-1.836.103-2.98.946-2.916 2.143.067 1.256 1.452 1.839 2.784 1.767 1.224-.065 2.818-.543 3.086-3.71a10.5 10.5 0 0 0-2.215-.221z",
  fb:"M13.4 19v-6.2h2.1l.4-2.6h-2.5V8.6c0-.8.3-1.3 1.4-1.3H16V5.1c-.3 0-1.1-.1-2-.1-2 0-3.3 1.2-3.3 3.4v1.8H8.5v2.6h2.2V19z"
};
const COL = {whatsapp:"#25D366",tiktok:"#000",x:"#000",threads:"#000"};
function Ic(name, color, s) {
  s = s || 14;
  const a = {viewBox:"0 0 24 24", width:s, height:s, style:{flexShrink:0, display:"block"}};
  if (name === "fb") return h("svg", a, h("circle",{cx:12,cy:12,r:12,fill:"#1877F2"}), h("path",{d:P.fb,fill:"#fff"}));
  if (name === "instagram") return h("svg", {...a,fill:"none",stroke:"#E4405F",strokeWidth:2},
    h("rect",{x:3,y:3,width:18,height:18,rx:5}), h("circle",{cx:12,cy:12,r:4}), h("circle",{cx:17.5,cy:6.5,r:1.1,fill:"#E4405F",stroke:"none"}));
  return h("svg", {...a, fill: COL[name] || color}, h("path",{d:P[name]}));
}

const num = e => { const t = parseFloat(String(e||"").replace(/,/g,"")); return isNaN(t) ? 0 : t; };
const naira = e => e ? new Intl.NumberFormat("en-NG").format(e) : "—";
function words(n) {
  if (!n) return "Zero";
  const o=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"];
  const t=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];
  const f=x=>x<20?o[x]:x<100?t[Math.floor(x/10)]+(x%10?" "+o[x%10]:""):o[Math.floor(x/100)]+" Hundred"+(x%100?" and "+f(x%100):"");
  const sc=[""," Thousand"," Million"," Billion"]; let w="",i=0,v=Math.floor(n);
  while(v>0){const c=v%1000; if(c) w=f(c)+sc[i]+(w?", "+w:""); v=Math.floor(v/1000); i++;}
  return w;
}
const load = () => { try { return JSON.parse(localStorage.getItem("supa_settings")||"{}"); } catch { return {}; } };

// Auto-sizing editable text
function Ed(p) {
  const v = p.value || "";
  return h("input", {value:v, placeholder:p.ph||"", onChange:e=>p.set(e.target.value), size:Math.max(4,v.length+1), onBlur:e=>{ e.target.scrollLeft=0; },
    className:"ed " + (p.cls||""), style:{maxWidth:"100%",...p.style}});
}

function App() {
  const S = useMemo(load, []);
  const [customer,setCustomer] = useState({name:"Emmanuel Okafor",tel:"0803 456 7890"});
  const [receiptNo,setReceiptNo] = useState(S.receiptNo||"0000043");
  const [rs,setRs] = useState(false);
  const nextNo = n => { const m=String(n).match(/^(.*?)(\d+)$/); return m ? m[1]+String(+m[2]+1).padStart(m[2].length,"0") : n; };
  const [dateInfo,setDateInfo] = useState({day:"17",month:"MAY",year:"2026"});
  const [branchKey,setBranchKey] = useState(S.branchKey||"lagos");
  const [pay,setPay] = useState("CASH");
  const [items,setItems] = useState(INITIAL_ITEMS);
  const [deposit,setDeposit] = useState("500000");
  const [name1,setName1] = useState(S.name1||"Supatroniks");
  const [name2,setName2] = useState(S.name2||"Nigeria Ltd");
  const [tagline,setTagline] = useState(S.tagline||"Quality electronics, appliances & generators");
  const [email,setEmail] = useState(S.email||"supatroniks@gmail.com");
  const [handle,setHandle] = useState(S.handle||"@supatroniks");
  const [signLabel,setSignLabel] = useState(S.signLabel||"Authorized Signatory");
  const [logo,setLogo] = useState(S.logo||null);
  const [logoSize,setLogoSize] = useState(S.logoSize||110);
  const [sign,setSign] = useState(S.sign||null);
  const [color,setColor] = useState(S.color||"#0F766E");
  const [dark,setDark] = useState(S.dark||"#134E4A");
  const [busy,setBusy] = useState(false);
  const logoIn = useRef(), signIn = useRef();
  const [raw,setRaw] = useState(null); const [crop,setCrop] = useState(null); const drag = useRef(null);
  const br = BRANCHES[branchKey];

  useEffect(()=>{ try { localStorage.setItem("supa_settings", JSON.stringify({receiptNo,branchKey,name1,name2,tagline,email,handle,signLabel,logo,logoSize,sign,color,dark})); } catch {} },
    [receiptNo,branchKey,name1,name2,tagline,email,handle,signLabel,logo,logoSize,sign,color,dark]);

  const calc = useMemo(()=>{
    const amounts = items.map(i=>num(i.qty)*num(i.rate));
    const total = amounts.reduce((a,c)=>a+c,0);
    return {amounts,total,balance:Math.max(0,total-num(deposit))};
  },[items,deposit]);

  const setItem = (i,f,v) => setItems(p=>p.map((it,x)=>x===i?{...it,[f]:v}:it));

  const brandFrom = url => new Promise(res=>{
    const img=new Image(); img.onload=()=>{ try {
      const c=document.createElement("canvas"); c.width=c.height=48; const x=c.getContext("2d"); x.drawImage(img,0,0,48,48);
      const d=x.getImageData(0,0,48,48).data, b={};
      for(let i=0;i<d.length;i+=4){ const r=d[i],g=d[i+1],bl=d[i+2]; if(d[i+3]<128) continue;
        const mx=Math.max(r,g,bl),mn=Math.min(r,g,bl); if((mx>245&&mn>230)||mx<30) continue;
        const k=[r,g,bl].map(v=>Math.round(v/24)*24).join(","); b[k]=(b[k]||0)+1; }
      const s=Object.entries(b).sort((a,c)=>c[1]-a[1]); const hex=k=>"#"+k.split(",").map(v=>Math.min(255,+v).toString(16).padStart(2,"0")).join("");
      let p="#0F766E", dk="#134E4A";
      for(const [k] of s){ const [r,g,bl]=k.split(",").map(Number); if((Math.max(r,g,bl)-Math.min(r,g,bl))/(Math.max(r,g,bl)||1)>.5){p=hex(k);break;} }
      for(const [k] of s){ const [r,g,bl]=k.split(",").map(Number); if(.299*r+.587*g+.114*bl<55){dk=hex(k);break;} }
      res({p,dk}); } catch { res(null); } };
    img.onerror=()=>res(null); img.src=url; });

  const readFile = (e,cb) => { const f=e.target.files?.[0]; if(!f) return; const r=new FileReader(); r.onload=ev=>cb(ev.target.result); r.readAsDataURL(f); e.target.value=""; };
  const openCrop = u => { const i=new Image(); i.onload=()=>{ setRaw(u); setCrop({z:1,x:0,y:0,nw:i.naturalWidth,nh:i.naturalHeight}); }; i.src=u; };
  const onLogo = e => readFile(e, async u=>{ setLogo(u); openCrop(u); const c=await brandFrom(u); if(c){setColor(c.p);setDark(c.dk);} });
  const applyCrop = () => { const F=260, i=new Image(); i.onload=()=>{ const o=512, k=o/F, cv=document.createElement("canvas"); cv.width=cv.height=o;
    const s=F/Math.max(crop.nw,crop.nh)*crop.z, w=crop.nw*s, hh=crop.nh*s;
    cv.getContext("2d").drawImage(i,((F-w)/2+crop.x)*k,((F-hh)/2+crop.y)*k,w*k,hh*k); setLogo(cv.toDataURL("image/png")); setCrop(null); }; i.src=raw; };

  const capture = async () => {
    const el=document.getElementById("receipt");
    if(document.fonts?.ready) await document.fonts.ready;
    return html2canvas(el,{scale:3,useCORS:true,allowTaint:true,logging:false,backgroundColor:"#fff",windowWidth:1000,onclone:doc=>{ const rc=doc.getElementById("receipt"); if(rc){ rc.style.width="808px"; rc.style.maxWidth="808px"; }
      doc.querySelectorAll(".no-print").forEach(n=>n.remove());
      doc.querySelectorAll("input").forEach(inp=>{
        const cs=getComputedStyle(inp), d=doc.createElement("div"), right=cs.textAlign==="right";
        d.textContent=inp.value||inp.placeholder||"";
        d.style.cssText=`width:${inp.offsetWidth}px;height:${inp.offsetHeight||28}px;display:flex;align-items:center;justify-content:${right?"flex-end":cs.textAlign==="center"?"center":"flex-start"};font:${cs.font};color:${cs.color};background:${cs.backgroundColor};padding:${cs.padding};box-sizing:border-box;white-space:nowrap;border-bottom:${cs.borderBottomWidth} ${cs.borderBottomStyle==="dashed"?"solid transparent":cs.borderBottomStyle} ${cs.borderBottomColor};`;
        if(!inp.value) d.style.color="#cbd5e1"; inp.parentNode.replaceChild(d,inp);
      });
    }});
  };
  const watermark = src => new Promise(res=>{
    if(!logo) return res(src);
    const c=document.createElement("canvas"); c.width=src.width; c.height=src.height;
    const x=c.getContext("2d"); x.drawImage(src,0,0);
    const l=new Image(); l.onload=()=>{ const s=Math.round(src.width*.07), st=Math.round(s*1.7); x.globalAlpha=.07;
      for(let b=-10;b<22;b++){ const o=b*st*.65; for(let i=-5;i<26;i++){ const px=i*st+o, py=i*st*.52; if(px>-s&&px<c.width+s&&py>-s&&py<c.height+s) x.drawImage(l,px,py,s,s); } }
      x.globalAlpha=1; res(c); };
    l.onerror=()=>res(src); l.src=logo; });
  const fname = ext => `${(name1+"_"+name2).replace(/\W+/g,"_")}_Receipt_${receiptNo||"INV"}.${ext}`;
  const savePNG = async () => { try { setBusy(true); const c=await watermark(await capture());
    await deliver(fname("png"),"image/png",c.toDataURL("image/png",1).split(",")[1]); setReceiptNo(nextNo(receiptNo)); }
    catch(e){alert("Image error: "+(e.message||e));} finally{setBusy(false);} };
  const savePDF = async () => { try { setBusy(true); const c=await watermark(await capture());
    const pdf=new jsPDF({orientation:"portrait",unit:"mm",format:"a4"});
    const pw=pdf.internal.pageSize.getWidth(), ph=pdf.internal.pageSize.getHeight(), m=6;
    let iw=pw-m*2, ih=c.height*iw/c.width; if(ih>ph-m*2){ih=ph-m*2; iw=c.width*ih/c.height;}
    pdf.addImage(c.toDataURL("image/png",1),"PNG",(pw-iw)/2,(ph-ih)/2,iw,ih); await deliver(fname("pdf"),"application/pdf",pdf.output("datauristring").split("base64,")[1]); setReceiptNo(nextNo(receiptNo)); }
    catch(e){alert("PDF error: "+(e.message||e));} finally{setBusy(false);} };

  const pill = "h-8 px-3.5 rounded-full text-[11px] font-medium border bg-white border-slate-200 text-slate-700 whitespace-nowrap shrink-0";
  const lbl = "text-[9px] font-semibold uppercase tracking-[0.15em] text-slate-400";
  const th = "py-3 px-3 text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400";
  const contact = (icon,child) => h("span",{className:"inline-flex items-center gap-1.5"}, Ic(icon,color,14), child);

  return h("div",{className:"min-h-screen overflow-x-clip"},
    crop && raw && h("div",{className:"no-print fixed inset-0 z-50 flex items-center justify-center p-4",style:{backgroundColor:"rgba(0,0,0,.55)"}},
      h("div",{className:"bg-white rounded-2xl shadow-2xl w-full max-w-[360px] p-4"},
        h("div",{className:"flex justify-between items-center mb-3"},h("b",{className:"text-[14px]"},"Crop Logo"),h("button",{onClick:()=>setCrop(null),className:"text-slate-400 text-[13px]"},"Cancel")),
        h("div",{className:"relative mx-auto overflow-hidden rounded-xl border border-slate-200 select-none",
          style:{width:260,height:260,touchAction:"none",cursor:"grab",backgroundColor:"#e2e8f0"},
          onPointerDown:e=>{ e.currentTarget.setPointerCapture(e.pointerId); drag.current={px:e.clientX,py:e.clientY,x:crop.x,y:crop.y}; },
          onPointerMove:e=>{ const d=drag.current; if(d) setCrop(c=>({...c,x:d.x+e.clientX-d.px,y:d.y+e.clientY-d.py})); },
          onPointerUp:()=>{drag.current=null;}, onPointerCancel:()=>{drag.current=null;}},
          (()=>{ const s=260/Math.max(crop.nw,crop.nh)*crop.z, w=crop.nw*s, hh=crop.nh*s;
            return h("img",{src:raw,draggable:false,style:{position:"absolute",maxWidth:"none",pointerEvents:"none",width:w,height:hh,left:(260-w)/2+crop.x,top:(260-hh)/2+crop.y}}); })(),
          h("div",{className:"pointer-events-none absolute inset-0 rounded-xl",style:{boxShadow:"inset 0 0 0 2px rgba(255,255,255,.9)"}})),
        h("p",{className:"mt-2 text-center text-[11px] text-slate-400"},"Drag the logo to move it. Use the slider to zoom."),
        h("div",{className:"mt-2 flex items-center gap-3"},h("span",{className:lbl},"Zoom"),
          h("input",{type:"range",min:0.3,max:4,step:0.02,value:crop.z,onChange:e=>setCrop({...crop,z:+e.target.value}),className:"flex-1",style:{accentColor:color}}),
          h("span",{className:"font-mono text-[11px] font-bold w-10 text-right"},crop.z.toFixed(1)+"×")),
        h("div",{className:"mt-4 flex gap-2"},
          h("button",{onClick:()=>setCrop({...crop,z:1,x:0,y:0}),className:"flex-1 h-10 rounded-xl border border-slate-200 text-[12px] font-semibold text-slate-600"},"Reset"),
          h("button",{onClick:applyCrop,className:"flex-[1.4] h-10 rounded-xl text-white text-[12px] font-bold",style:{backgroundColor:color}},"Apply Crop")))),
    h("div",{className:"no-print sticky top-0 z-30 backdrop-blur-xl border-b bg-white/90 border-slate-200"},
      h("div",{className:"mx-auto max-w-[840px] px-3 py-2"},
        h("div",{className:"toolbar-scroll flex gap-2 overflow-x-auto"},
          h("input",{type:"file",accept:"image/*",ref:logoIn,onChange:onLogo,className:"hidden"}),
          h("input",{type:"file",accept:"image/*",ref:signIn,onChange:e=>readFile(e,setSign),className:"hidden"}),
          h("button",{onClick:()=>logoIn.current.click(),className:pill},logo?"Change Logo":"Upload Logo"),
          logo && h("button",{onClick:()=>openCrop(raw||logo),className:pill},"Crop Logo"),
          h("button",{onClick:()=>signIn.current.click(),className:pill},sign?"Sign ✓":"Upload Sign"),
          h("button",{onClick:savePNG,disabled:busy,className:"h-8 px-3.5 rounded-full text-[11px] font-semibold bg-slate-900 text-white shrink-0 disabled:opacity-50"},busy?"…":"Save PNG"),
          h("button",{onClick:savePDF,disabled:busy,className:"h-8 px-4 rounded-full text-[11px] font-semibold text-white shrink-0 disabled:opacity-50",style:{backgroundColor:color}},busy?"…":"Save PDF")),
        h("div",{className:"mt-2 flex items-center gap-3 px-1"},
          h("span",{className:lbl},"Logo size"),
          h("input",{type:"range",min:60,max:200,step:4,value:logoSize,onChange:e=>setLogoSize(+e.target.value),className:"flex-1",style:{accentColor:color}}),
          h("span",{className:"font-mono text-[11px] font-bold w-10 text-right"},logoSize)))),

    h("div",{className:"mx-auto max-w-[840px] px-2 sm:px-4 py-6"},
      h("div",{id:"receipt",className:"bg-white w-full overflow-hidden",style:{borderRadius:16,boxShadow:"0 8px 24px -4px rgba(0,0,0,.08),0 0 0 1px rgba(0,0,0,.03)"}},
        h("div",{className:"h-1.5",style:{background:`linear-gradient(90deg,${color},${dark} 60%,${color})`}}),
        h("div",{className:"p-5 sm:p-8"},

          // Header
          h("div",{className:"flex flex-col md:flex-row gap-5 md:gap-8"},
            h("div",{className:"flex items-start gap-4 flex-1 min-w-0"},
              h("div",{className:"shrink-0 flex items-center justify-center cursor-pointer",style:{width:logoSize,height:logoSize,maxWidth:"100%"},onClick:()=>logoIn.current.click()},
                logo ? h("img",{src:logo,alt:"Logo",className:"w-full h-full object-contain"}) : h("span",{className:"text-4xl",style:{color}},"⚡")),
              h("div",{className:"min-w-0"},
                h("p",{className:"text-[10px] font-semibold uppercase tracking-[0.2em] mb-1",style:{color}},"Sales Receipt"),
                h("div",{className:"flex flex-col items-start"},
                  h(Ed,{value:name1,set:setName1,cls:"text-[26px] sm:text-[32px] font-extrabold leading-[1.1] text-slate-900"}),
                  h(Ed,{value:name2,set:setName2,cls:"text-[24px] sm:text-[30px] font-bold leading-[1.1]",style:{color}})),
                h(Ed,{value:tagline,set:setTagline,cls:"mt-1.5 text-[12px] text-slate-500 w-full"}),
                h("div",{className:"mt-2 flex flex-wrap gap-1.5"},
                  h("span",{className:"px-2 py-0.5 rounded-full text-[9px] font-semibold uppercase",style:{backgroundColor:color+"15",color}},"● RC Verified"),
                  h("span",{className:"px-2 py-0.5 rounded-full text-[9px] font-semibold uppercase text-white",style:{backgroundColor:dark}},br.tag)))),
            h("div",{className:"shrink-0 w-full md:w-[240px] rounded-2xl p-4 border border-slate-100 bg-slate-50"},
              h("div",{className:"flex justify-between items-center mb-1"},h("div",{className:lbl},"Receipt No."),
                h("button",{className:"no-print text-[10px] font-semibold",style:{color:rs?"#dc2626":color},onClick:()=>{ if(rs){setReceiptNo("0000001");setRs(false);} else {setRs(true); setTimeout(()=>setRs(false),3000);} }},rs?"Tap again to reset to 0000001":"Reset")),
              h("div",{className:"flex items-baseline gap-0.5 mb-3"},
                h("span",{className:"font-mono text-slate-300"},"#"),
                h("input",{value:receiptNo,onChange:e=>setReceiptNo(e.target.value),className:"flex-1 min-w-0 bg-transparent font-mono font-bold text-[22px] outline-none"})),
              h("div",{className:"inline-flex px-2.5 py-1 rounded-full text-[9px] font-bold uppercase text-white mb-3",style:{backgroundColor:color}},"● Valid Document"),
              h("div",{className:lbl+" mb-1.5"},"Date"),
              h("div",{className:"grid grid-cols-3 gap-1.5"},
                ["day","month","year"].map(k=>h("input",{key:k,value:dateInfo[k],onChange:e=>setDateInfo({...dateInfo,[k]:e.target.value.toUpperCase()}),
                  className:"w-full bg-white rounded-lg px-1 py-2 font-bold text-center uppercase border border-slate-200",style:{fontSize:12}}))))),

          // Contacts
          h("div",{className:"mt-6 py-3 border-y border-slate-100 space-y-2.5 text-[12px] text-slate-600"},
            h("div",{className:"flex flex-wrap items-center gap-x-4 gap-y-1.5"},
              contact("call",h("span",{className:"font-semibold text-slate-800"},br.phones.join(" / "))),
              contact("whatsapp",h("span",{className:"font-semibold text-slate-800"},br.phones[0])),
              contact("mail",h(Ed,{value:email,set:setEmail,cls:"text-[12px]"}))),
            h("div",{className:"flex flex-wrap items-center gap-x-2.5 gap-y-1.5"},
              ["fb","instagram","tiktok","x","threads"].map(n=>h("span",{key:n},Ic(n,color,16))),
              h(Ed,{value:handle,set:setHandle,cls:"text-[12px] font-medium"})),
            h("div",{className:"no-print flex items-center gap-2"},
              h("span",{className:lbl},"Branch"),
              h("select",{value:branchKey,onChange:e=>setBranchKey(e.target.value),className:"bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-[12px] font-semibold"},
                Object.entries(BRANCHES).map(([k,b])=>h("option",{key:k,value:k},b.name))))),
          h("p",{className:"mt-2 text-[11px] text-slate-400"},br.name+": "+br.address),

          // Customer / payment
          h("div",{className:"mt-6 grid grid-cols-1 sm:grid-cols-2 gap-5"},
            h("div",null,
              h("div",{className:lbl+" mb-2"},"Bill To"),
              h("input",{value:customer.name,onChange:e=>setCustomer({...customer,name:e.target.value}),placeholder:"Customer name or company",className:"w-full font-semibold text-[16px] border-b-2 border-slate-100 pb-1.5 bg-transparent"}),
              h("input",{value:customer.tel,onChange:e=>setCustomer({...customer,tel:e.target.value}),placeholder:"Phone number",className:"w-full mt-2.5 text-[13px] text-slate-500 border-b border-slate-100 pb-1 bg-transparent"})),
            h("div",null,
              h("div",{className:lbl+" mb-2"},"Payment Method"),
              h("div",{className:"flex gap-2"},["CASH","TRANSFER","POS"].map(m=>h("button",{key:m,type:"button",onClick:()=>setPay(m),
                className:"flex-1 py-2.5 rounded-xl text-[11px] font-bold border "+(pay===m?"text-white border-transparent":"bg-slate-50 text-slate-400 border-slate-100"),
                style:pay===m?{backgroundColor:color}:{}},m))))),

          // Items
          h("div",{className:"mt-7 overflow-x-auto rounded-xl border border-slate-100"},
            h("table",{className:"w-full min-w-[480px] text-[13px] border-collapse"},
              h("thead",null,h("tr",{className:"bg-slate-50"},
                h("th",{className:th+" text-left w-9"},"#"),h("th",{className:th+" text-center w-14"},"Qty"),
                h("th",{className:th+" text-left"},"Description"),h("th",{className:th+" text-right w-[105px]"},"Rate"),
                h("th",{className:th+" text-right w-[120px] !text-white",style:{backgroundColor:color}},"Amount"))),
              h("tbody",null,items.map((it,i)=>{ const a=calc.amounts[i];
                return h("tr",{key:i,className:"border-t border-slate-50 "+(!it.desc&&!it.qty&&!it.rate?"opacity-30":"")},
                  h("td",{className:"py-2 px-3 font-mono text-[11px] text-slate-300"},String(i+1).padStart(2,"0")),
                  h("td",{className:"py-1.5 px-1"},h("input",{value:it.qty,onChange:e=>setItem(i,"qty",e.target.value),placeholder:"—",className:"w-full h-8 bg-slate-50 rounded-lg text-center font-mono font-semibold text-[12px]"})),
                  h("td",{className:"py-1.5 px-1"},h("input",{value:it.desc,onChange:e=>setItem(i,"desc",e.target.value),placeholder:i<3?"":"Item description…",className:"w-full h-8 bg-transparent rounded-lg px-2.5 font-medium text-[13px]"})),
                  h("td",{className:"py-1.5 px-1"},h("input",{value:it.rate,onChange:e=>setItem(i,"rate",e.target.value),placeholder:"—",className:"w-full h-8 bg-slate-50 rounded-lg px-2 text-right font-mono font-semibold text-[12px]"})),
                  h("td",{className:"py-1.5 px-3"},h("div",{className:"h-8 flex items-center justify-end font-mono font-bold text-[13px] "+(a?"text-slate-900":"text-slate-300")},a?"₦"+naira(a):"—")));
              })))),

          // Totals
          h("div",{className:"mt-6 grid grid-cols-1 sm:grid-cols-[1fr_270px] gap-5"},
            h("div",{className:"space-y-3"},
              h("div",null,h("div",{className:lbl+" mb-1.5"},"Amount in Words"),
                h("div",{className:"rounded-xl px-4 py-3.5 text-[13px] font-medium italic min-h-[48px] flex items-center border border-slate-100",style:{backgroundColor:color+"0A",color:"#334155"}},
                  calc.total?words(calc.total)+" Naira Only":"— Enter line items above")),
              h("p",{className:"text-[11px] text-slate-400 leading-relaxed"},h("span",{className:"font-semibold text-slate-500"},"Terms — "),"Goods in good condition are non-returnable. Warranty per manufacturer. Keep this receipt for warranty claims.")),
            h("div",{className:"rounded-2xl overflow-hidden border border-slate-100"},
              h("div",{className:"flex justify-between items-center px-4 py-3 bg-slate-50"},h("span",{className:"text-[12px] text-slate-500"},"Subtotal"),h("span",{className:"font-mono font-semibold text-[14px]"},"₦"+naira(calc.total))),
              h("div",{className:"flex justify-between items-center px-4 py-3 border-t border-slate-100"},h("span",{className:"text-[12px] text-slate-500"},"Deposit"),
                h("div",{className:"flex items-center gap-1"},h("span",{className:"font-mono text-[12px] text-slate-400"},"₦"),
                  h("input",{value:deposit,onChange:e=>setDeposit(e.target.value),className:"w-[100px] h-8 text-right font-mono font-bold text-[13px] bg-slate-50 rounded-lg px-2"}))),
              h("div",{className:"flex justify-between items-center px-4 py-4 text-white",style:{backgroundColor:dark}},h("span",{className:"text-[11px] font-bold uppercase tracking-wider"},"Balance Due"),h("span",{className:"font-mono font-extrabold text-[20px]"},"₦"+naira(calc.balance))),
              h("div",{className:"flex justify-between px-4 py-2 text-[10px] font-semibold",style:{backgroundColor:color+"12",color:dark}},h("span",null,"via ",h("strong",null,pay)),h("span",{style:{color}},"VALID")))),

          // Signatures
          h("div",{className:"mt-10 grid grid-cols-2 gap-8 sm:gap-16"},
            h("div",null,h("div",{className:"h-14 border-b border-dashed border-slate-300"}),h("div",{className:"mt-2 "+lbl},"Customer Signature")),
            h("div",{className:"flex flex-col items-end"},
              h("div",{className:"h-14 w-full border-b border-dashed border-slate-300 flex items-end justify-end cursor-pointer",onClick:()=>signIn.current.click()},
                sign?h("img",{src:sign,alt:"Sign",className:"max-h-12 max-w-[160px] object-contain"}):h("span",{className:"no-print text-[10px] text-slate-300"},"Tap to sign")),
              h(Ed,{value:signLabel,set:setSignLabel,cls:"mt-2 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400 text-right"}))),

          // Footer
          h("div",{className:"mt-8 flex flex-col sm:flex-row items-center justify-between gap-2 py-3.5 px-5 rounded-2xl text-white",style:{backgroundColor:dark}},
            h("span",{className:"text-[11px] font-semibold"},"Thank you for your patronage"),
            h("span",{className:"text-[10px] font-mono opacity-60"},name1+" "+name2+" · "+br.name+" · "+new Date().getFullYear())),
          h("p",{className:"mt-3 text-center text-[9px] font-mono text-slate-300"},"ORIGINAL · CUSTOMER COPY · RETAIN FOR WARRANTY")))));
}
createRoot(document.getElementById("root")).render(h(App));